(() => {
  // ../../tmp/uidongi-usb-stage-76105qbw/public/load-data.js
  var bundled = { "catalogue": { "meta": { "title": "의성 여행 조사 후보 목록", "version": 2, "status": "research-pending", "sourceAccessAttemptedAt": "2026-10-24", "sourceAccessResult": "클라우드 네트워크 정책에서 공식 원문 HTTPS 조회가 403으로 차단됨. 자료 확인일이 아님.", "description": "일반적으로 알려진 명칭을 바탕으로 만든 조사 후보. 공식 자료에서 선별·검증한 관광 DB가 아님. 위치·운영·요금·예약은 미확인. 권역·동행 적합도·소요시간은 편집상 가정.", "regions": { "central": "의성·봉양·안평권", "south": "금성·가음·춘산권", "east": "단촌·점곡·옥산권", "west": "안계·비안·다인권" } }, "places": [{ "id": "sanun", "name": "산운마을", "region": "south", "categories": ["볼거리"], "audiences": ["연인", "혼자"], "minutes": 90, "indoor": false, "group": "산운", "description": "전통 마을 풍경과 골목 산책을 고려할 후보입니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "sanun-eco", "name": "산운생태공원", "region": "south", "categories": ["볼거리"], "audiences": ["가족", "연인"], "minutes": 60, "indoor": false, "group": "산운", "description": "마을 주변에서 가볍게 걷는 일정의 후보입니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "jomon-ruins", "name": "조문국 사적지", "region": "south", "categories": ["볼거리"], "audiences": ["연인", "친구"], "minutes": 70, "indoor": false, "group": "조문국", "description": "유적과 야외 풍경을 함께 살펴볼 후보입니다. 꽃 풍경은 개화 확인이 필요합니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "jomon-museum", "name": "의성조문국박물관", "region": "south", "categories": ["볼거리"], "audiences": ["가족", "혼자"], "minutes": 90, "indoor": true, "group": "조문국", "description": "지역 역사 전시를 살펴보는 실내 관람 후보입니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "tapri-pagoda", "name": "의성 탑리리 오층석탑", "region": "south", "categories": ["볼거리"], "audiences": ["혼자", "가족"], "minutes": 40, "indoor": false, "group": "탑리", "description": "문화유산을 중심으로 짧게 둘러볼 후보입니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "dinosaur", "name": "의성 제오리 공룡발자국 화석산지", "region": "south", "categories": ["볼거리"], "audiences": ["가족", "친구"], "minutes": 40, "indoor": false, "group": "제오리", "description": "지질과 공룡에 관심 있는 여행의 후보입니다. 관람 구역 접근을 확인해 주세요.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "geumseong-mountain", "name": "금성산", "region": "south", "categories": ["볼거리"], "audiences": ["친구", "혼자"], "minutes": 180, "indoor": false, "group": "금성산", "description": "등산 중심 여행의 후보입니다. 탐방로 통제와 난이도 확인이 필요합니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "bibong-mountain", "name": "비봉산", "region": "south", "categories": ["볼거리"], "audiences": ["친구"], "minutes": 180, "indoor": false, "group": "비봉산", "description": "활동적인 산행 후보입니다. 등산 장비와 탐방로 상황을 확인해 주세요.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "binggye", "name": "빙계계곡", "region": "south", "categories": ["볼거리"], "audiences": ["연인", "친구"], "minutes": 90, "indoor": false, "group": "빙계", "description": "계곡 주변 풍경을 즐기는 후보입니다. 물놀이나 접근 가능 여부를 보장하지 않습니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "binggye-seowon", "name": "빙계서원", "region": "south", "categories": ["볼거리"], "audiences": ["혼자", "가족"], "minutes": 45, "indoor": false, "group": "빙계", "description": "계곡 인근 문화유산을 둘러보는 후보입니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "sujeongsa", "name": "수정사", "region": "south", "categories": ["볼거리"], "audiences": ["혼자", "연인"], "minutes": 60, "indoor": false, "group": "수정사", "description": "조용한 사찰 방문 후보입니다. 종교시설 예절과 개방 구역을 확인해 주세요.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "gounsa", "name": "고운사", "region": "east", "categories": ["볼거리"], "audiences": ["혼자", "연인"], "minutes": 90, "indoor": false, "group": "고운사", "description": "산불 피해 이후 복구와 방문 가능 구역을 공식 안내에서 먼저 확인해야 하는 후보입니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": true, "holdReason": "산불 영향과 현재 운영 여부 우선 확인", "requiresPet": false }, { "id": "choe-literature", "name": "최치원문학관", "region": "east", "categories": ["볼거리"], "audiences": ["혼자", "가족"], "minutes": 60, "indoor": true, "group": "고운사", "description": "전시 운영과 방문 가능 여부의 우선 확인이 필요한 후보입니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": true, "holdReason": "산불 영향과 현재 운영 여부 우선 확인", "requiresPet": false }, { "id": "sachon", "name": "사촌마을", "region": "east", "categories": ["볼거리"], "audiences": ["연인", "가족"], "minutes": 90, "indoor": false, "group": "사촌", "description": "전통 마을과 골목 풍경을 살펴볼 후보입니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "sachon-forest", "name": "사촌가로숲", "region": "east", "categories": ["볼거리"], "audiences": ["연인", "혼자"], "minutes": 50, "indoor": false, "group": "사촌", "description": "숲길 산책 후보입니다. 마을과 가까운 시설은 코스에서 중복을 줄입니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "sowoodang", "name": "의성 소우당", "region": "south", "categories": ["볼거리"], "audiences": ["연인", "혼자"], "minutes": 40, "indoor": false, "group": "산운", "description": "고택 문화유산 후보입니다. 사유 공간의 관람 및 출입 가능 여부를 확인해야 합니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "geumbong", "name": "금봉자연휴양림", "region": "east", "categories": ["숙박", "볼거리"], "audiences": ["가족", "연인"], "minutes": 90, "indoor": false, "group": "금봉", "description": "숲에서 쉬거나 숙박을 알아볼 후보입니다. 산불 영향·시설 운영·예약 상태는 별도 확인이 필요합니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": true, "bookingUrl": null, "hold": true, "holdReason": "산불 영향과 현재 운영 여부 우선 확인", "requiresPet": false }, { "id": "daegoksa", "name": "대곡사", "region": "west", "categories": ["볼거리"], "audiences": ["혼자", "연인"], "minutes": 70, "indoor": false, "group": "대곡사", "description": "역사와 사찰 풍경을 함께 살펴볼 후보입니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "saengsong", "name": "의성 생송리 마애보살좌상", "region": "west", "categories": ["볼거리"], "audiences": ["혼자", "친구"], "minutes": 45, "indoor": false, "group": "생송", "description": "불교 문화유산을 살펴볼 후보입니다. 현장 접근성을 먼저 확인해 주세요.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "nakdan", "name": "낙단보", "region": "west", "categories": ["볼거리"], "audiences": ["연인", "친구"], "minutes": 60, "indoor": false, "group": "낙단", "description": "강 주변 산책과 풍경을 고려할 후보입니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "uiseong-school", "name": "의성향교", "region": "central", "categories": ["볼거리"], "audiences": ["혼자", "가족"], "minutes": 45, "indoor": false, "group": "의성향교", "description": "향교 문화와 전통 공간을 살펴볼 후보입니다. 개방 여부를 확인해 주세요.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "bian-school", "name": "비안향교", "region": "west", "categories": ["볼거리"], "audiences": ["혼자", "가족"], "minutes": 45, "indoor": false, "group": "비안", "description": "짧은 문화유산 방문 후보입니다. 개방 여부를 확인해 주세요.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "heron", "name": "의성왜가리생태관", "region": "east", "categories": ["볼거리", "체험"], "audiences": ["가족"], "minutes": 90, "indoor": true, "group": "왜가리", "description": "생태 전시 관람 후보입니다. 체험은 별도 운영 프로그램 확인이 필요합니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": true, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "wood", "name": "의성목재문화체험장", "region": "east", "categories": ["체험"], "audiences": ["가족", "연인", "친구"], "minutes": 90, "indoor": true, "group": "목재", "description": "목재 만들기 체험 후보입니다. 실제 프로그램·연령·운영 장소·예약을 확인해야 합니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": true, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "curling", "name": "의성컬링센터", "region": "central", "categories": ["체험"], "audiences": ["친구", "가족"], "minutes": 120, "indoor": true, "group": "컬링", "description": "컬링 체험을 알아볼 후보입니다. 일반 방문객 체험 운영 여부와 사전 예약이 필요합니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": true, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "petworld", "name": "의성펫월드", "region": "west", "categories": ["체험", "볼거리"], "audiences": ["가족", "친구"], "minutes": 120, "indoor": false, "group": "펫월드", "description": "반려견 동반 여행을 알아볼 후보입니다. 입장 규정과 접종·체급 조건을 확인해 주세요.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": true, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": true }, { "id": "angye-art", "name": "안계미술관", "region": "west", "categories": ["볼거리"], "audiences": ["연인", "혼자"], "minutes": 60, "indoor": true, "group": "안계", "description": "전시를 감상하는 실내 방문 후보입니다. 전시 교체 및 휴관을 확인해 주세요.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "binggye-camp", "name": "빙계얼음골야영장", "region": "south", "categories": ["숙박"], "audiences": ["가족", "친구"], "minutes": 90, "indoor": false, "group": "빙계", "description": "캠핑 숙박 후보입니다. 장비 준비, 시설 운영, 예약 가능 여부를 확인해야 합니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": true, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "uiseong-market", "name": "의성전통시장", "region": "central", "categories": ["특산물 쇼핑"], "audiences": ["가족", "혼자", "친구"], "minutes": 60, "indoor": false, "group": "의성시장", "description": "지역 시장 장보기 후보입니다. 장날·품목·특산물 판매 여부는 확인이 필요합니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "angye-market", "name": "안계시장", "region": "west", "categories": ["특산물 쇼핑"], "audiences": ["가족", "친구"], "minutes": 60, "indoor": false, "group": "안계", "description": "서부권 장보기 후보입니다. 개장일과 의성산 특산물 취급 점포를 확인해 주세요.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "geumseong-market", "name": "금성시장", "region": "south", "categories": ["특산물 쇼핑"], "audiences": ["연인", "가족"], "minutes": 50, "indoor": false, "group": "탑리", "description": "남부권 장보기 후보입니다. 시장 운영일과 판매 품목을 확인해 주세요.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "bongyang-market", "name": "봉양시장", "region": "central", "categories": ["특산물 쇼핑"], "audiences": ["친구", "혼자"], "minutes": 50, "indoor": false, "group": "봉양", "description": "지역 시장 방문 후보입니다. 영업 점포와 판매 품목을 확인해 주세요.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "dain-market", "name": "다인시장", "region": "west", "categories": ["특산물 쇼핑"], "audiences": ["가족", "혼자"], "minutes": 50, "indoor": false, "group": "다인", "description": "서부권 전통시장 방문 후보입니다. 장날과 판매 품목을 확인해 주세요.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "unramsa", "name": "운람사", "region": "central", "categories": ["볼거리"], "audiences": ["혼자"], "minutes": 60, "indoor": false, "group": "운람사", "description": "한적한 사찰 방문 후보입니다. 운영 및 출입 가능 여부를 확인해 주세요.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }, { "id": "gwandeok-pagoda", "name": "의성 관덕리 삼층석탑", "region": "east", "categories": ["볼거리"], "audiences": ["혼자", "친구"], "minutes": 40, "indoor": false, "group": "관덕", "description": "석탑 문화유산을 살펴볼 후보입니다. 표기·접근 경로의 공식 확인이 필요합니다.", "verification": "pending", "sourceUrl": null, "sourceCheckedAt": null, "researchTargets": ["https://www.usc.go.kr/", "https://korean.visitkorea.or.kr/"], "address": null, "coordinates": null, "openingHours": null, "closedWeekdays": null, "price": null, "bookingRequired": false, "bookingUrl": null, "hold": false, "holdReason": null, "requiresPet": false }] }, "dining": [{ "id": "MOCK-001", "name": "[가상] 마늘달빛 밥상", "category": "맛집", "categories": ["맛집"], "region": "central", "area": "의성읍", "cuisine": "한식", "menu": "마늘솥밥·된장국", "price": 14e3, "audiences": ["연인", "가족"], "atmosphere": "차분한 식사", "minutes": 70, "openTime": "11:00", "closeTime": "20:00", "closedWeekdays": [1], "closedLabel": "월", "reservation": "가능", "petPolicy": "불가", "parking": true, "noise": "보통", "space": "실내", "breakTime": null, "tags": ["마늘 요리"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-002", "name": "[가상] 돌담한상", "category": "맛집", "categories": ["맛집"], "region": "south", "area": "금성면", "cuisine": "한식", "menu": "들깨버섯정식", "price": 13e3, "audiences": ["가족", "혼자"], "atmosphere": "편안한 한 끼", "minutes": 60, "openTime": "11:00", "closeTime": "19:30", "closedWeekdays": [2], "closedLabel": "화", "reservation": "가능", "petPolicy": "불가", "parking": true, "noise": "보통", "space": "실내", "breakTime": null, "tags": ["담백한 식사"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-003", "name": "[가상] 별빛마늘구이", "category": "맛집", "categories": ["맛집"], "region": "central", "area": "봉양면", "cuisine": "고깃집", "menu": "마늘구이 고기모둠", "price": 32e3, "audiences": ["친구", "가족"], "atmosphere": "활기찬 저녁", "minutes": 100, "openTime": "16:00", "closeTime": "22:00", "closedWeekdays": [3], "closedLabel": "수", "reservation": "권장", "petPolicy": "불가", "parking": true, "noise": "높음", "space": "실내", "breakTime": null, "tags": ["고기", "저녁"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-004", "name": "[가상] 초록들 국수집", "category": "맛집", "categories": ["맛집"], "region": "west", "area": "안계면", "cuisine": "면요리", "menu": "들깨국수·비빔국수", "price": 9e3, "audiences": ["혼자", "친구"], "atmosphere": "간단한 점심", "minutes": 45, "openTime": "10:30", "closeTime": "18:30", "closedWeekdays": [4], "closedLabel": "목", "reservation": "불가", "petPolicy": "불가", "parking": false, "noise": "보통", "space": "실내", "breakTime": null, "tags": ["가벼운 식사"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-005", "name": "[가상] 산운가든 키친", "category": "맛집", "categories": ["맛집"], "region": "south", "area": "금성면", "cuisine": "양식", "menu": "허브치킨·토마토파스타", "price": 22e3, "audiences": ["연인", "친구"], "atmosphere": "데이트 식사", "minutes": 90, "openTime": "11:30", "closeTime": "21:00", "closedWeekdays": [1], "closedLabel": "월", "reservation": "권장", "petPolicy": "테라스만", "parking": true, "noise": "낮음", "space": "실내·테라스", "breakTime": null, "tags": ["데이트"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-006", "name": "[가상] 작은들 비빔밥", "category": "맛집", "categories": ["맛집"], "region": "west", "area": "다인면", "cuisine": "한식", "menu": "계절나물비빔밥", "price": 11e3, "audiences": ["혼자", "가족"], "atmosphere": "소박한 점심", "minutes": 50, "openTime": "11:00", "closeTime": "18:00", "closedWeekdays": [2], "closedLabel": "화", "reservation": "불가", "petPolicy": "불가", "parking": false, "noise": "보통", "space": "실내", "breakTime": null, "tags": ["나물", "점심"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-007", "name": "[가상] 사촌골 만두방", "category": "맛집", "categories": ["맛집"], "region": "east", "area": "점곡면", "cuisine": "분식", "menu": "손만두전골·찐만두", "price": 12e3, "audiences": ["가족", "친구"], "atmosphere": "따뜻한 식사", "minutes": 60, "openTime": "11:00", "closeTime": "20:00", "closedWeekdays": [3], "closedLabel": "수", "reservation": "가능", "petPolicy": "불가", "parking": true, "noise": "보통", "space": "실내", "breakTime": null, "tags": ["만두"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-008", "name": "[가상] 고요한 숲 한정식", "category": "맛집", "categories": ["맛집"], "region": "east", "area": "단촌면", "cuisine": "한정식", "menu": "숲나물한상", "price": 28e3, "audiences": ["연인", "가족"], "atmosphere": "조용한 기념일", "minutes": 100, "openTime": "11:30", "closeTime": "20:00", "closedWeekdays": [1], "closedLabel": "월", "reservation": "필수", "petPolicy": "불가", "parking": true, "noise": "낮음", "space": "실내", "breakTime": null, "tags": ["기념일"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-009", "name": "[가상] 금빛들 도시락", "category": "맛집", "categories": ["맛집"], "region": "central", "area": "의성읍", "cuisine": "도시락", "menu": "마늘불고기도시락", "price": 1e4, "audiences": ["혼자", "친구"], "atmosphere": "포장 중심", "minutes": 30, "openTime": "10:00", "closeTime": "17:00", "closedWeekdays": [0], "closedLabel": "일", "reservation": "가능", "petPolicy": "불가", "parking": false, "noise": "보통", "space": "실내", "breakTime": ["포장 전용"], "tags": ["포장"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-010", "name": "[가상] 강바람 생선구이", "category": "맛집", "categories": ["맛집"], "region": "west", "area": "단밀면", "cuisine": "한식", "menu": "생선구이정식", "price": 16e3, "audiences": ["가족", "혼자"], "atmosphere": "든든한 한 끼", "minutes": 60, "openTime": "11:00", "closeTime": "20:00", "closedWeekdays": [4], "closedLabel": "목", "reservation": "가능", "petPolicy": "불가", "parking": true, "noise": "보통", "space": "실내", "breakTime": null, "tags": ["생선"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-011", "name": "[가상] 들꽃채소 식탁", "category": "맛집", "categories": ["맛집"], "region": "east", "area": "옥산면", "cuisine": "채소요리", "menu": "구운채소덮밥·채소수프", "price": 15e3, "audiences": ["연인", "혼자"], "atmosphere": "가벼운 채소 식사", "minutes": 70, "openTime": "11:00", "closeTime": "19:00", "closedWeekdays": [2], "closedLabel": "화", "reservation": "권장", "petPolicy": "불가", "parking": true, "noise": "낮음", "space": "실내", "breakTime": null, "tags": ["채소 중심"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-012", "name": "[가상] 빙계온기 국밥", "category": "맛집", "categories": ["맛집"], "region": "south", "area": "춘산면", "cuisine": "국밥", "menu": "맑은소고기국밥", "price": 11e3, "audiences": ["혼자", "가족"], "atmosphere": "빠르고 든든하게", "minutes": 40, "openTime": "08:00", "closeTime": "19:00", "closedWeekdays": [3], "closedLabel": "수", "reservation": "불가", "petPolicy": "불가", "parking": true, "noise": "보통", "space": "실내", "breakTime": null, "tags": ["아침 식사"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-013", "name": "[가상] 두런두런 화덕집", "category": "맛집", "categories": ["맛집"], "region": "central", "area": "안평면", "cuisine": "양식", "menu": "마늘화덕피자", "price": 19e3, "audiences": ["가족", "친구"], "atmosphere": "함께 나누는 식사", "minutes": 90, "openTime": "11:30", "closeTime": "21:00", "closedWeekdays": [1], "closedLabel": "월", "reservation": "권장", "petPolicy": "테라스만", "parking": true, "noise": "높음", "space": "실내·테라스", "breakTime": null, "tags": ["피자"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-014", "name": "[가상] 마늘향 작은초밥", "category": "맛집", "categories": ["맛집"], "region": "central", "area": "의성읍", "cuisine": "일식", "menu": "구운마늘초밥세트", "price": 23e3, "audiences": ["연인", "혼자"], "atmosphere": "차분한 바 좌석", "minutes": 70, "openTime": "11:30", "closeTime": "21:00", "closedWeekdays": [2], "closedLabel": "화", "reservation": "권장", "petPolicy": "불가", "parking": false, "noise": "낮음", "space": "실내", "breakTime": ["14:30", "17:00"], "tags": ["초밥"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-015", "name": "[가상] 초승달 닭요리", "category": "맛집", "categories": ["맛집"], "region": "west", "area": "비안면", "cuisine": "닭요리", "menu": "간장마늘닭구이", "price": 21e3, "audiences": ["가족", "친구"], "atmosphere": "함께 먹는 저녁", "minutes": 90, "openTime": "12:00", "closeTime": "21:00", "closedWeekdays": [4], "closedLabel": "목", "reservation": "가능", "petPolicy": "불가", "parking": true, "noise": "보통", "space": "실내", "breakTime": ["15:00", "17:00"], "tags": ["닭요리"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-016", "name": "[가상] 안계한그릇", "category": "맛집", "categories": ["맛집"], "region": "west", "area": "안계면", "cuisine": "덮밥", "menu": "버섯소고기덮밥", "price": 12e3, "audiences": ["혼자", "연인"], "atmosphere": "깔끔한 한 그릇", "minutes": 45, "openTime": "11:00", "closeTime": "20:00", "closedWeekdays": [0], "closedLabel": "일", "reservation": "불가", "petPolicy": "불가", "parking": false, "noise": "보통", "space": "실내", "breakTime": null, "tags": ["혼밥"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-017", "name": "[가상] 온유한 들밥", "category": "맛집", "categories": ["맛집"], "region": "west", "area": "단북면", "cuisine": "한식", "menu": "두부버섯전골", "price": 17e3, "audiences": ["가족", "연인"], "atmosphere": "여유로운 식사", "minutes": 80, "openTime": "11:00", "closeTime": "20:00", "closedWeekdays": [1], "closedLabel": "월", "reservation": "가능", "petPolicy": "불가", "parking": true, "noise": "낮음", "space": "실내", "breakTime": null, "tags": ["전골"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-018", "name": "[가상] 노을고기 마당", "category": "맛집", "categories": ["맛집"], "region": "west", "area": "다인면", "cuisine": "고깃집", "menu": "마늘양념구이", "price": 29e3, "audiences": ["친구", "가족"], "atmosphere": "야외 저녁 모임", "minutes": 110, "openTime": "16:00", "closeTime": "22:00", "closedWeekdays": [2], "closedLabel": "화", "reservation": "필수", "petPolicy": "테라스만", "parking": true, "noise": "높음", "space": "실내·테라스", "breakTime": null, "tags": ["저녁 모임"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-019", "name": "[가상] 초록우편 커피", "category": "카페", "categories": ["카페"], "region": "central", "area": "의성읍", "cuisine": "커피", "menu": "아메리카노·마늘크림스콘", "price": 9e3, "audiences": ["연인", "혼자"], "atmosphere": "조용한 휴식", "minutes": 70, "openTime": "10:00", "closeTime": "20:00", "closedWeekdays": [1], "closedLabel": "월", "reservation": "불가", "petPolicy": "불가", "parking": false, "noise": "낮음", "space": "실내", "breakTime": null, "tags": ["커피", "독서"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-020", "name": "[가상] 사과빛 베이크룸", "category": "카페", "categories": ["카페"], "region": "east", "area": "옥산면", "cuisine": "베이커리", "menu": "사과타르트·라테", "price": 12e3, "audiences": ["연인", "가족"], "atmosphere": "디저트와 대화", "minutes": 80, "openTime": "10:00", "closeTime": "19:00", "closedWeekdays": [2], "closedLabel": "화", "reservation": "가능", "petPolicy": "테라스만", "parking": true, "noise": "보통", "space": "실내·테라스", "breakTime": null, "tags": ["베이커리"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-021", "name": "[가상] 구름산책 티하우스", "category": "카페", "categories": ["카페"], "region": "south", "area": "금성면", "cuisine": "차", "menu": "허브차·쌀케이크", "price": 11e3, "audiences": ["연인", "혼자"], "atmosphere": "차분한 티타임", "minutes": 90, "openTime": "11:00", "closeTime": "19:00", "closedWeekdays": [3], "closedLabel": "수", "reservation": "권장", "petPolicy": "불가", "parking": true, "noise": "낮음", "space": "실내", "breakTime": null, "tags": ["차", "휴식"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-022", "name": "[가상] 강변느린커피", "category": "카페", "categories": ["카페"], "region": "west", "area": "단밀면", "cuisine": "커피", "menu": "콜드브루·치즈케이크", "price": 1e4, "audiences": ["연인", "친구"], "atmosphere": "풍경과 대화", "minutes": 80, "openTime": "10:00", "closeTime": "21:00", "closedWeekdays": [4], "closedLabel": "목", "reservation": "불가", "petPolicy": "테라스만", "parking": true, "noise": "보통", "space": "실내·테라스", "breakTime": null, "tags": ["사진", "커피"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-023", "name": "[가상] 콩닥콩닥 디저트", "category": "카페", "categories": ["카페"], "region": "west", "area": "안계면", "cuisine": "디저트", "menu": "과일와플·우유라테", "price": 13e3, "audiences": ["가족", "친구"], "atmosphere": "밝고 활기찬 공간", "minutes": 70, "openTime": "11:00", "closeTime": "21:00", "closedWeekdays": [1], "closedLabel": "월", "reservation": "가능", "petPolicy": "불가", "parking": false, "noise": "높음", "space": "실내", "breakTime": null, "tags": ["와플"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-024", "name": "[가상] 사촌책방 카페", "category": "카페", "categories": ["카페"], "region": "east", "area": "점곡면", "cuisine": "북카페", "menu": "핸드드립·파운드케이크", "price": 1e4, "audiences": ["혼자", "연인"], "atmosphere": "독서와 휴식", "minutes": 100, "openTime": "10:30", "closeTime": "18:30", "closedWeekdays": [2], "closedLabel": "화", "reservation": "불가", "petPolicy": "불가", "parking": true, "noise": "낮음", "space": "실내", "breakTime": null, "tags": ["독서"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-025", "name": "[가상] 작은정원 로스터스", "category": "카페", "categories": ["카페"], "region": "central", "area": "봉양면", "cuisine": "커피", "menu": "핸드드립·버터쿠키", "price": 9e3, "audiences": ["혼자", "친구"], "atmosphere": "커피 중심", "minutes": 60, "openTime": "09:00", "closeTime": "19:00", "closedWeekdays": [3], "closedLabel": "수", "reservation": "불가", "petPolicy": "테라스만", "parking": true, "noise": "보통", "space": "실내·테라스", "breakTime": null, "tags": ["커피"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-026", "name": "[가상] 노을담은 찻집", "category": "카페", "categories": ["카페"], "region": "west", "area": "다인면", "cuisine": "전통차", "menu": "대추차·인절미", "price": 11e3, "audiences": ["가족", "연인"], "atmosphere": "느긋한 대화", "minutes": 90, "openTime": "11:00", "closeTime": "20:00", "closedWeekdays": [4], "closedLabel": "목", "reservation": "권장", "petPolicy": "불가", "parking": true, "noise": "낮음", "space": "실내", "breakTime": null, "tags": ["전통차"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-027", "name": "[가상] 달보드레 쌀빵집", "category": "카페", "categories": ["카페"], "region": "central", "area": "의성읍", "cuisine": "베이커리", "menu": "쌀소금빵·카페라테", "price": 9e3, "audiences": ["가족", "혼자"], "atmosphere": "가벼운 포장", "minutes": 45, "openTime": "08:30", "closeTime": "18:00", "closedWeekdays": [1], "closedLabel": "월", "reservation": "불가", "petPolicy": "불가", "parking": false, "noise": "보통", "space": "실내", "breakTime": null, "tags": ["아침", "포장"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-028", "name": "[가상] 숲멍 한잔", "category": "카페", "categories": ["카페"], "region": "east", "area": "단촌면", "cuisine": "커피", "menu": "드립커피·당근케이크", "price": 11e3, "audiences": ["연인", "혼자"], "atmosphere": "조용한 쉼", "minutes": 100, "openTime": "10:00", "closeTime": "18:00", "closedWeekdays": [2], "closedLabel": "화", "reservation": "가능", "petPolicy": "테라스만", "parking": true, "noise": "낮음", "space": "실내·테라스", "breakTime": null, "tags": ["휴식"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-029", "name": "[가상] 빙계여름 빙수방", "category": "카페", "categories": ["카페"], "region": "south", "area": "춘산면", "cuisine": "빙수", "menu": "우유빙수·과일에이드", "price": 14e3, "audiences": ["가족", "친구"], "atmosphere": "시원한 간식", "minutes": 60, "openTime": "11:00", "closeTime": "20:00", "closedWeekdays": [3], "closedLabel": "수", "reservation": "불가", "petPolicy": "불가", "parking": true, "noise": "높음", "space": "실내", "breakTime": null, "tags": ["빙수"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }, { "id": "MOCK-030", "name": "[가상] 별자리 밤카페", "category": "카페", "categories": ["카페"], "region": "west", "area": "비안면", "cuisine": "커피", "menu": "디카페인라테·초코케이크", "price": 12e3, "audiences": ["연인", "친구"], "atmosphere": "늦은 저녁 대화", "minutes": 90, "openTime": "13:00", "closeTime": "22:30", "closedWeekdays": [4], "closedLabel": "목", "reservation": "권장", "petPolicy": "테라스만", "parking": true, "noise": "보통", "space": "실내·테라스", "breakTime": null, "tags": ["야간", "디카페인"], "isMock": true, "verification": "fictional", "address": null, "phone": null, "bookingUrl": null, "sourceUrl": null }], "events": [], "travelTable": { "meta": { "status": "unavailable", "description": "기존 데이터에는 구간·권역별 이동시간표, 지도 API, 도로망 자료가 없습니다. 숫자를 새로 만들어 넣지 않았습니다. 빈 목록은 이동 0분을 뜻하지 않습니다.", "schema": "routes: from, to, transport, minutes, basis(fictional/published), source, bidirectional(선택). regionRoutes: fromRegion, toRegion 및 같은 필드." }, "routes": [], "regionRoutes": [] }, "warnings": [] };
  async function loadTripData() {
    return JSON.parse(JSON.stringify(bundled));
  }

  // ../../tmp/uidongi-usb-stage-76105qbw/public/dining.js
  function diningTextOptions(text) {
    const result = {};
    if (/맛집|식당|한식|음식점/.test(text)) result.category = "맛집";
    if (/카페|커피|디저트|찻집|베이커리|빙수/.test(text)) result.category = result.category ? "all" : "카페";
    if (/연인|커플|데이트/.test(text)) result.companion = "연인";
    else if (/가족|아이/.test(text)) result.companion = "가족";
    else if (/혼자|혼밥/.test(text)) result.companion = "혼자";
    else if (/친구/.test(text)) result.companion = "친구";
    if (/조용|차분|독서/.test(text)) result.quiet = true;
    if (/주차/.test(text)) result.parkingOnly = true;
    if (/반려견|강아지|애견/.test(text)) result.withPet = true;
    const amount = text.match(/(?:(\d+(?:\.\d+)?)\s*만\s*(?:(\d+)\s*천)?|([\d,]+))\s*원\s*(이하|이내|미만)/);
    if (amount) result.maxDiningPrice = (amount[1] ? Number(amount[1]) * 1e4 + Number(amount[2] || 0) * 1e3 : Number(amount[3].replaceAll(",", ""))) - (amount[4] === "미만" ? 1 : 0);
    return result;
  }
  function normalized(text) {
    return text.toLowerCase().replace(/\[가상\]/g, "").replace(/\s+/g, "");
  }
  function searchDining(places, options = {}) {
    const query = (options.query || options.diningQuery || "").trim();
    const parsed = diningTextOptions(query), merged = { ...parsed, ...options, maxDiningPrice: Number(options.maxDiningPrice) || parsed.maxDiningPrice || 0, quiet: options.quiet || parsed.quiet, parkingOnly: options.parkingOnly || parsed.parkingOnly };
    const category = options.category && options.category !== "all" ? options.category : parsed.category || "all";
    let keyword = query.replace(/(?:맛집|식당|음식점|카페|커피)(?:만|들|좀|를|을)?/g, " ").replace(/(?:\d+(?:\.\d+)?\s*만\s*(?:\d+\s*천)?|[\d,]+)\s*원\s*(?:이하|이내|미만)/g, " ").replace(/조용한?|차분한?|독서|주차(?:가능한|가능)?|반려견|강아지|애견|연인|커플|데이트|가족|아이|혼자|혼밥|친구/g, " ").replace(/이나|또는|혹은|그리고|및/g, " ").replace(/[,.!?]/g, " ").replace(/추천(?:해줘|해주세요)?|찾아(?:줘|주세요)|알려(?:줘|주세요)|에서|이랑|함께|단둘이|(?:^|\s)(?:과|와|를|을|은|는|가|이)(?=\s|$)/g, " ").trim();
    const terms = keyword ? normalized(keyword) : "";
    return places.filter((p) => {
      if (!p.isMock || p.verification !== "fictional") return false;
      if (category !== "all" && p.category !== category) return false;
      if (merged.region && merged.region !== "all" && p.region !== merged.region) return false;
      if (merged.maxDiningPrice && p.price > Number(merged.maxDiningPrice)) return false;
      if (merged.parkingOnly && !p.parking) return false;
      if (merged.quiet && p.noise !== "낮음") return false;
      if (merged.environment === "outdoor" && !p.space?.includes("테라스")) return false;
      if (merged.environment === "indoor" && merged.withPet && p.petPolicy === "테라스만") return false;
      if (merged.withPet && p.petPolicy === "불가") return false;
      if (merged.date) {
        const day = (/* @__PURE__ */ new Date(merged.date + "T00:00:00Z")).getUTCDay();
        if (p.closedWeekdays?.includes(day)) return false;
      }
      const searchable = normalized([p.name, p.menu, p.cuisine, p.area, p.category, p.atmosphere, ...p.tags].join(" "));
      if (terms && !searchable.includes(terms)) return false;
      return true;
    }).sort((a, b) => Number(b.audiences.includes(merged.companion)) - Number(a.audiences.includes(merged.companion)) || a.price - b.price || a.id.localeCompare(b.id));
  }

  // ../../tmp/uidongi-usb-stage-76105qbw/public/recommendation-reasons.js
  function recommendationReasons(place, context) {
    const { options, interests: interests2, start, end, dayStart, dayEnd, provisional } = context;
    const reasons = [];
    if (options.companion && place.audiences?.includes(options.companion)) {
      reasons.push({ code: "companion", text: `${options.companion} 여행 조건과 일치` });
    }
    const matches = (place.categories || []).filter((category) => interests2.includes(category));
    if (matches.length) {
      const nature = options.themes?.includes("nature") && place.themeMatch === true && matches.includes("볼거리");
      reasons.push({ code: "interest", text: nature ? "자연·힐링 관심사와 일치 (이름·야외 분류 기준)" : `${matches.join("·")} 관심사와 일치` });
    }
    const validSlot = [start, end, dayStart, dayEnd].every(Number.isFinite) && start >= dayStart && end <= dayEnd && end - start === place.minutes;
    if (validSlot && !provisional) {
      if (place.category === "맛집" && matches.includes("맛집") && start >= 690 && start <= 840) {
        reasons.push({ code: "lunch", text: "점심시간에 맞춘 식사 장소" });
      }
      reasons.push({ code: "time-budget", text: "입력·등록 시간 기준 여행시간 내 배치" });
    }
    return reasons;
  }

  // ../../tmp/uidongi-usb-stage-76105qbw/public/scheduler.js
  var isTime = (value) => typeof value === "string" && /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value);
  var toMinutes = (value) => {
    const [h, m] = value.split(":").map(Number);
    return h * 60 + m;
  };
  var toClock = (value) => `${String(Math.floor(value / 60)).padStart(2, "0")}:${String(value % 60).padStart(2, "0")}`;
  var commercialTypes = /* @__PURE__ */ new Set(["맛집", "카페", "특산물 쇼핑"]);
  function resolveTravel(from, to, transport, table, allowance) {
    if (!from) return null;
    const match = (Array.isArray(table?.routes) ? table.routes : []).find((r) => r && r.transport === transport && (r.from === from.id && r.to === to.id || r.bidirectional === true && r.to === from.id && r.from === to.id)) || (Array.isArray(table?.regionRoutes) ? table.regionRoutes : []).find((r) => r && r.transport === transport && (r.fromRegion === from.region && r.toRegion === to.region || r.bidirectional === true && r.toRegion === from.region && r.fromRegion === to.region));
    if (match && Number.isInteger(match.minutes) && match.minutes >= 0 && ["fictional", "published"].includes(match.basis) && typeof match.source === "string" && match.source.trim()) {
      return { minutes: match.minutes, basis: match.basis, source: match.source, label: match.basis === "fictional" ? "가상 이동시간" : "등록된 이동시간(실시간 아님)" };
    }
    if (allowance !== "" && allowance !== null && allowance !== void 0 && Number.isFinite(Number(allowance)) && Number(allowance) > 0) {
      return { minutes: Number(allowance), basis: "user", source: "사용자가 입력한 구간당 이동 여유", label: "사용자 지정 이동 여유 · 실제 시간 확인 필요" };
    }
    return { minutes: null, basis: "unknown", source: null, label: "이동시간 확인 필요" };
  }
  function openingWindow(place) {
    const raw = place.openingHours;
    const open = place.openTime ?? raw?.open ?? raw?.openTime;
    const close = place.closeTime ?? raw?.close ?? raw?.closeTime;
    if (open == null && close == null) return { known: false, breaks: [] };
    if (!isTime(open) || !(isTime(close) || close === "24:00") || toMinutes(close) <= toMinutes(open)) return { invalid: true };
    const breaks = place.breakTime ? [place.breakTime] : raw?.breaks || [];
    if (!Array.isArray(breaks) || breaks.some((pair) => !Array.isArray(pair) || pair.length !== 2 || !pair.every(isTime) || toMinutes(pair[0]) >= toMinutes(pair[1]))) return { invalid: true };
    return { known: true, open: toMinutes(open), close: toMinutes(close), breaks: breaks.map((pair) => pair.map(toMinutes)).sort((a, b) => a[0] - b[0]) };
  }
  function visitSlots(place, arrival, limit, date, preferLunch) {
    const weekday = date ? (/* @__PURE__ */ new Date(date + "T00:00:00Z")).getUTCDay() : null;
    const closed = place.closedWeekdays ?? place.openingHours?.closedWeekdays;
    if (weekday !== null && closed?.includes(weekday)) return [];
    const hours = openingWindow(place);
    if (hours.invalid || !Number.isInteger(place.minutes) || place.minutes <= 0) return [];
    function fit(earliest) {
      let start = Math.max(earliest, hours.known ? hours.open : earliest);
      if (hours.known) {
        for (const [from, to] of hours.breaks) if (start < to && start + place.minutes > from) start = to;
      }
      const end = start + place.minutes;
      if (end > limit || hours.known && end > hours.close) return null;
      return { start, end, openingKnown: hours.known };
    }
    const candidates = [fit(arrival)];
    if (preferLunch && arrival <= 840 && limit >= 690) candidates.push(fit(Math.max(arrival, 690)));
    return candidates.filter((slot, index, array) => slot && array.findIndex((p) => p?.start === slot.start) === index);
  }
  var compare = (a, b) => {
    for (let i = 0; i < a.rank.length; i++) if (a.rank[i] !== b.rank[i]) return b.rank[i] - a.rank[i];
    return a.signature.localeCompare(b.signature);
  };
  function planDay({ candidates, start, end, date, interests: interests2, options, travelTable: travelTable2, usedIds = /* @__PURE__ */ new Set(), usedGroups = /* @__PURE__ */ new Set(), previousCoverage = /* @__PURE__ */ new Set() }) {
    const wanted = new Set(interests2);
    const maxStops = options.pace === "active" ? 8 : options.pace === "relaxed" ? 4 : 6;
    const touristCap = options.duration === "반나절" || options.pace === "relaxed" ? 2 : options.pace === "active" ? 6 : 4;
    const initial = { visits: [], timeline: [], cursor: start, ids: /* @__PURE__ */ new Set(), groups: /* @__PURE__ */ new Set(), covered: /* @__PURE__ */ new Set(), matchPoints: 0, companionPoints: 0, hoursKnown: 0, unknownTravel: 0, travelMinutes: 0, waitMinutes: 0, mealScore: 0, signature: "", rank: [0, 0, 0, 0, 0, 0, 0, 0] };
    let beam = [initial], best = initial;
    for (let depth = 0; depth < maxStops; depth++) {
      const next = [];
      for (const state2 of beam) {
        for (const place of candidates) {
          if (usedIds.has(place.id) || state2.ids.has(place.id) || usedGroups.has(place.group) || state2.groups.has(place.group)) continue;
          if (place.kind === "place" && state2.visits.filter((p) => p.kind === "place").length >= touristCap) continue;
          if (["맛집", "카페"].includes(place.category) && state2.visits.some((p) => p.category === place.category)) continue;
          const matches = place.categories.filter((c) => wanted.has(c));
          if (!matches.length) continue;
          const last = state2.visits.at(-1);
          const travel = resolveTravel(last, place, options.transport, travelTable2, options.travelAllowanceMinutes);
          const arrival = state2.cursor + (travel?.minutes ?? 0);
          const slots = visitSlots(place, arrival, end, date, place.category === "맛집");
          for (const slot of slots) {
            const timeline = [...state2.timeline];
            const provisional = state2.unknownTravel > 0 || travel?.basis === "unknown";
            if (travel) timeline.push({ kind: "travel", from: last.title, to: place.title, time: toClock(state2.cursor), endTime: travel.minutes === null ? null : toClock(arrival), minutes: travel.minutes, basis: travel.basis, source: travel.source, label: travel.label, provisional });
            if (slot.start > arrival) timeline.push({ kind: "wait", time: toClock(arrival), endTime: toClock(slot.start), minutes: slot.start - arrival, label: "운영시간에 맞춘 대기·휴식", provisional });
            const stop = { ...place, time: toClock(slot.start), endTime: toClock(slot.end), openingKnown: slot.openingKnown, openingLabel: slot.openingKnown ? place.isMock ? "가상 운영시간 충족" : "등록 운영시간 충족" : "운영시간 확인 필요", dateChecked: Boolean(date) && Array.isArray(place.closedWeekdays ?? place.openingHours?.closedWeekdays), provisional, incomingTravel: travel };
            stop.reasons = recommendationReasons(place, { options, interests: [...wanted], start: slot.start, end: slot.end, dayStart: start, dayEnd: end, provisional });
            stop.reason = stop.reasons.map((reason) => reason.text).join(" · ");
            timeline.push(stop);
            const covered = /* @__PURE__ */ new Set([...state2.covered, ...matches]);
            const ids = /* @__PURE__ */ new Set([...state2.ids, place.id]), groups = /* @__PURE__ */ new Set([...state2.groups, place.group]);
            const nextState = {
              visits: [...state2.visits, stop],
              timeline,
              cursor: slot.end,
              ids,
              groups,
              covered,
              matchPoints: state2.matchPoints + matches.length + (place.themeMatch ? 1 : 0),
              companionPoints: state2.companionPoints + Number(place.audiences.includes(options.companion)),
              hoursKnown: state2.hoursKnown + Number(slot.openingKnown),
              unknownTravel: state2.unknownTravel + Number(travel?.basis === "unknown"),
              travelMinutes: state2.travelMinutes + (travel?.minutes ?? 0),
              waitMinutes: state2.waitMinutes + slot.start - arrival,
              mealScore: state2.mealScore + Number(place.category === "맛집" && slot.start >= 690 && slot.start <= 840) * 2 + Number(Boolean(place.category === "카페" && last && last.kind === "place")),
              signature: [...state2.visits.map((p) => p.id), place.id, toClock(slot.start)].join("|")
            };
            nextState.rank = [covered.size + [...covered].filter((c) => !previousCoverage.has(c)).length, nextState.matchPoints, nextState.companionPoints, nextState.hoursKnown, -nextState.unknownTravel, -nextState.travelMinutes, nextState.mealScore, -nextState.waitMinutes];
            next.push(nextState);
            if (compare(nextState, best) < 0) best = nextState;
          }
        }
      }
      if (!next.length) break;
      next.sort(compare);
      const keys = /* @__PURE__ */ new Set();
      beam = next.filter((s) => {
        const key = [...s.ids].sort().join(",") + "|" + s.visits.at(-1).id + "|" + s.cursor;
        if (keys.has(key)) return false;
        keys.add(key);
        return true;
      }).slice(0, 32);
    }
    return { stops: best.visits, timeline: best.timeline, usedIds: best.ids, usedGroups: best.groups, covered: best.covered, rank: best.rank, signature: best.signature };
  }
  function summarizeDays(days, budgetMinutes) {
    const stops = days.flatMap((d) => d.stops), segments = days.flatMap((d) => d.timeline);
    const moves = segments.filter((s) => s.kind === "travel");
    const unknownTravelLegs = moves.filter((s) => s.minutes === null).length;
    const knownTravelMinutes = moves.reduce((sum, s) => sum + (s.minutes ?? 0), 0);
    const commercial = stops.filter((p) => p.categories.some((c) => commercialTypes.has(c)));
    const totalStayMinutes = stops.reduce((sum, p) => sum + p.minutes, 0);
    const totalWaitMinutes = segments.filter((s) => s.kind === "wait").reduce((sum, s) => sum + s.minutes, 0);
    return {
      totalVisitCount: stops.length,
      totalStayMinutes,
      knownTravelMinutes,
      totalTravelMinutes: unknownTravelLegs ? null : knownTravelMinutes,
      unknownTravelLegs,
      totalWaitMinutes,
      budgetMinutes,
      plannedMinutes: totalStayMinutes + knownTravelMinutes + totalWaitMinutes,
      timingProvisional: unknownTravelLegs > 0,
      unknownOpeningCount: stops.filter((p) => !p.openingKnown).length,
      fictionalTravelMinutes: moves.filter((s) => s.basis === "fictional").reduce((n, s) => n + s.minutes, 0),
      userAllowanceMinutes: moves.filter((s) => s.basis === "user").reduce((n, s) => n + s.minutes, 0),
      commercialCount: commercial.length,
      commercialMockCount: commercial.filter((p) => p.isMock).length,
      commercialCandidateCount: commercial.filter((p) => !p.isMock && p.verification !== "verified").length,
      commercialVerifiedCount: commercial.filter((p) => !p.isMock && p.verification === "verified").length
    };
  }

  // ../../tmp/uidongi-usb-stage-76105qbw/public/planner.js
  var durations = ["반나절", "당일치기", "1박 2일", "2박 3일"];
  var companions = ["혼자", "연인", "친구", "가족"];
  var interests = ["볼거리", "맛집", "카페", "체험", "특산물 쇼핑", "축제", "숙박"];
  var interestPatterns = {
    "볼거리": /볼거리|풍경|산책|관광|자연|힐링|사진|사찰|전시|박물관|등산/,
    "맛집": /맛집|식당|밥집|고깃집|음식|식사|한우|마늘소|먹거리/,
    "카페": /카페|커피|디저트|찻집|베이커리|빙수/,
    "체험": /체험|만들기|액티비티|컬링/,
    "특산물 쇼핑": /특산물|쇼핑|사고|구매|시장|장보기|살\s*곳/,
    "축제": /축제|행사/,
    "숙박": /숙박|하룻밤|호텔|펜션|캠핑|1\s*박|2\s*박/
  };
  function parsePrompt(text) {
    const result = { interests: [], excludedInterests: [] };
    if (/2\s*박\s*3\s*일|2\s*박|3\s*일/.test(text)) result.duration = "2박 3일";
    else if (/1\s*박|2\s*일|하룻밤/.test(text)) result.duration = "1박 2일";
    else if (/반나절|오전만|오후만/.test(text)) result.duration = "반나절";
    else if (/당일|하루/.test(text)) result.duration = "당일치기";
    if (/가족|아이|어린이|부모|엄마|아빠/.test(text)) result.companion = "가족";
    else if (/연인|커플|남자친구|여자친구|단둘/.test(text)) result.companion = "연인";
    else if (/친구/.test(text)) result.companion = "친구";
    else if (/혼자|나홀로/.test(text)) result.companion = "혼자";
    for (const [key, pattern] of Object.entries(interestPatterns)) {
      const negative = new RegExp(`(?:${pattern.source})(?:은|는|을|를|도|이|가|에| )*(?:빼|제외|말고|싫|안\\s*할|안\\s*가|필요\\s*없|원하지\\s*않)`);
      if (negative.test(text)) result.excludedInterests.push(key);
      else if (pattern.test(text)) result.interests.push(key);
    }
    if (/반려견|강아지|애견/.test(text)) result.withPet = true;
    if (/캠핑/.test(text)) result.lodgingType = "camping";
    if (/대중교통|버스|뚜벅이|기차/.test(text)) result.transport = "public";
    else if (/자가용|자동차|렌트|운전/.test(text)) result.transport = "car";
    if (/실내|비\s*오|우천/.test(text)) result.environment = "indoor";
    else if (/야외|실외/.test(text)) result.environment = "outdoor";
    if (/느긋|여유|천천히|쉬엄/.test(text)) result.pace = "relaxed";
    else if (/빡빡|알차|많이|활동적/.test(text)) result.pace = "active";
    const zones = { central: /의성읍|봉양|안평/, south: /금성|빙계|가음|춘산|산운|조문국/, east: /단촌|점곡|옥산|사촌|고운사/, west: /안계|비안|다인|낙단|펫월드/ };
    for (const [region, pattern] of Object.entries(zones)) if (pattern.test(text)) {
      result.region = region;
      break;
    }
    const date = text.match(/(20\d{2})[년.\-/]\s*(\d{1,2})[월.\-/]\s*(\d{1,2})일?/);
    if (date) {
      const value = `${date[1]}-${date[2].padStart(2, "0")}-${date[3].padStart(2, "0")}`;
      if (validDate(value)) result.date = value;
    }
    if (/자연|힐링|숲|산책/.test(text)) result.themes = ["nature"];
    const clock = text.match(/(?:(오전|오후)\s*)?(\d{1,2})(?::(\d{2})|시(?:\s*(\d{1,2})분)?)(?:\s*(?:부터|출발|시작))/);
    if (clock) {
      let hour = Number(clock[2]);
      if (clock[1] === "오후" && hour < 12) hour += 12;
      if (clock[1] === "오전" && hour === 12) hour = 0;
      const value = String(hour).padStart(2, "0") + ":" + String(Number(clock[3] || clock[4] || 0)).padStart(2, "0");
      if (isTime(value)) result.startTime = value;
    }
    const hours = text.match(/(?:총\s*)?(\d+(?:\.\d+)?)\s*시간(?:\s*(\d+)\s*분)?/);
    if (hours) result.availableHours = Number(hours[1]) + Number(hours[2] || 0) / 60;
    const diningOptions = diningTextOptions(text);
    for (const key of ["maxDiningPrice", "quiet", "parkingOnly"]) if (diningOptions[key] !== void 0) result[key] = diningOptions[key];
    const menu = text.match(/마늘|국수|피자|와플|빙수|초밥|만두|비빔밥|전통차|디카페인/);
    if (menu && result.interests.some((c) => c === "맛집" || c === "카페")) result.diningQuery = menu[0];
    return result;
  }
  function validDate(value) {
    return /^\d{4}-\d{2}-\d{2}$/.test(value || "") && !Number.isNaN(Date.parse(value)) && (/* @__PURE__ */ new Date(value + "T00:00:00Z")).toISOString().slice(0, 10) === value;
  }
  function dayDate(value, offset) {
    if (!validDate(value)) return null;
    const date = /* @__PURE__ */ new Date(value + "T00:00:00Z");
    date.setUTCDate(date.getUTCDate() + offset);
    return date.toISOString().slice(0, 10);
  }
  function defaultAvailableMinutes(duration) {
    return duration === "반나절" ? 240 : duration === "1박 2일" ? 960 : duration === "2박 3일" ? 1440 : 480;
  }
  var visitTypes = ["볼거리", "맛집", "카페", "체험", "특산물 쇼핑"];
  function comparePlans(a, b) {
    for (let i = 0; i < a.plan.rank.length; i++) if (a.plan.rank[i] !== b.plan.rank[i]) return b.plan.rank[i] - a.plan.rank[i];
    return a.plan.signature.localeCompare(b.plan.signature);
  }
  function normalizePlace(p, selected, options, isMock) {
    const category = p.categories.find((c) => selected.includes(c)) || p.categories[0];
    const themeMatch = Boolean(options.themes?.includes("nature") && !p.indoor && p.categories.includes("볼거리") && /산|숲|계곡|공원|마을|강|낙단보/.test(p.name));
    return {
      ...p,
      title: p.name,
      category,
      kind: isMock ? "mock-dining" : "place",
      group: p.group || p.id,
      isMock,
      area: p.area || null,
      description: isMock ? `가상 테스트 업소 · ${p.menu} · 1인 예산 ${p.price.toLocaleString("ko-KR")}원(가정). ${p.atmosphere}. 실제 업소·주소·예약 정보가 아닙니다.` : p.description,
      themeMatch,
      query: isMock ? null : "의성 " + p.name,
      sourceUrl: p.sourceUrl || null
    };
  }
  function buildTrip(options, catalogue2, events2 = [], dining2 = [], travelTable2 = { routes: [], regionRoutes: [] }) {
    if (!Array.isArray(catalogue2?.places) || !catalogue2?.meta?.regions) throw new Error("장소 자료를 불러오지 못했습니다. 새로고침해 주세요.");
    const count = options.duration === "2박 3일" ? 3 : options.duration === "1박 2일" ? 2 : 1;
    const startTime = options.startTime ?? "09:30";
    if (!isTime(startTime)) throw new Error("여행 시작시간을 00:00~23:59 형식으로 입력해 주세요.");
    const rawBudget = options.availableMinutes ?? (options.availableHours !== void 0 ? Number(options.availableHours) * 60 : defaultAvailableMinutes(options.duration));
    const budget = Math.round(Number(rawBudget));
    if (!Number.isFinite(Number(rawBudget)) || budget <= 0 || Math.abs(budget - Number(rawBudget)) > 1e-6) throw new Error("전체 여행 가능시간은 1분 이상의 분 단위 시간으로 입력해 주세요.");
    if (options.date && !validDate(options.date)) throw new Error("올바른 여행 날짜를 입력해 주세요.");
    if (options.region && options.region !== "all" && !catalogue2.meta.regions[options.region]) throw new Error("지원하는 여행 권역을 선택해 주세요.");
    const start = toMinutes(startTime);
    if (Math.ceil(budget / count) > 1440 - start) throw new Error("여행 가능시간을 일수로 나누면 하루 종료시간이 자정을 넘습니다. 시작시간·여행시간·기간을 조정해 주세요.");
    if (options.travelAllowanceMinutes !== "" && options.travelAllowanceMinutes != null && (!Number.isInteger(Number(options.travelAllowanceMinutes)) || Number(options.travelAllowanceMinutes) <= 0)) throw new Error("이동 여유는 비워두거나 1분 이상의 정수로 입력해 주세요.");
    const excluded = new Set(options.excludedInterests || []);
    const selected = [...new Set(options.interests || [])].filter((c) => !excluded.has(c));
    const wanted = selected.length ? selected.filter((c) => visitTypes.includes(c)) : excluded.has("볼거리") ? [] : ["볼거리"];
    const useMock = options.includeMock === true;
    const tourists = catalogue2.places.filter((p) => !p.hold && p.categories.some((c) => wanted.includes(c)) && !p.categories.some((c) => excluded.has(c)) && (p.verification === "verified" || options.includePending === true) && (!p.requiresPet || options.withPet) && (!options.withPet || p.requiresPet || p.petFriendly === true) && (!options.region || options.region === "all" || p.region === options.region) && (!options.environment || options.environment === "any" || (options.environment === "indoor" ? p.indoor : !p.indoor)) && p.id !== "binggye-camp").map((p) => normalizePlace(p, wanted, options, false));
    const diningPlaces = useMock ? searchDining(Array.isArray(dining2) ? dining2 : [], { ...options, query: options.diningQuery, date: null }).filter((p) => wanted.includes(p.category)).map((p) => normalizePlace(p, wanted, options, true)) : [];
    const candidates = [...tourists, ...diningPlaces];
    const usedIds = /* @__PURE__ */ new Set(), usedGroups = /* @__PURE__ */ new Set(), previousCoverage = /* @__PURE__ */ new Set(), days = [];
    for (let index = 0; index < count; index++) {
      const dayBudget = Math.floor(budget / count) + Number(index < budget % count), end = start + dayBudget, date = dayDate(options.date, index);
      const regions = options.region && options.region !== "all" ? [options.region] : Object.keys(catalogue2.meta.regions);
      const plans = regions.map((region) => ({ region, plan: planDay({ candidates: candidates.filter((p) => p.region === region), start, end, date, interests: wanted, options, travelTable: travelTable2, usedIds, usedGroups, previousCoverage }) })).sort(comparePlans);
      const result = plans[0];
      for (const id of result.plan.usedIds) usedIds.add(id);
      for (const group of result.plan.usedGroups) usedGroups.add(group);
      for (const c of result.plan.covered) previousCoverage.add(c);
      days.push({ day: index + 1, date, region: catalogue2.meta.regions[result.region] || result.region, startTime, endTime: toClock(end), budgetMinutes: dayBudget, stops: result.plan.stops, timeline: result.plan.timeline, missing: wanted.filter((c) => !result.plan.covered.has(c)) });
    }
    const stats = summarizeDays(days, budget);
    const scheduledEvents = selected.includes("축제") ? (events2 || []).filter((e) => e.verification === "verified" && validDate(e.startDate) && validDate(e.endDate) && days.some((d) => d.date && d.date >= e.startDate && d.date <= e.endDate)) : [];
    const missing = wanted.filter((c) => !previousCoverage.has(c));
    const notes = [
      "시작시간은 각 날짜의 첫 방문지 도착 기준입니다. 전체 활동 가능시간을 일수에 나누며, 날짜 간 이동·숙박·수면은 포함하지 않습니다.",
      "체류시간은 기존 JSON·CSV의 편집상 가정입니다. 일정은 관심사 일치, 동행 적합성, 운영시간·시간 예산 충족을 비교하는 제한된 후보 탐색으로 구성합니다. AI 또는 실시간 최단 경로를 사용하지 않습니다.",
      "같은 날짜에는 한 권역에서 구성하고 같은 장소·시설군은 여러 날에 걸쳐 반복하지 않습니다. 동행·권역·실내외·주차·예산·반려견 조건은 데이터가 있는 범위에서만 적용합니다."
    ];
    if (stats.unknownTravelLegs) notes.push(`이동시간 확인 필요: ${stats.unknownTravelLegs}구간. 숫자를 만들지 않았으며 이후 방문 시각과 운영시간 충족은 이동 미반영 최소 시각 기준입니다. 전체 종료시간을 보장하는 확정 일정이 아닙니다.`);
    if (stats.userAllowanceMinutes) notes.push("사용자가 지정한 이동 여유를 시간 예산에 포함했습니다. 실제 이동시간이나 가상 이동시간표에서 가져온 값은 아닙니다.");
    if (stats.fictionalTravelMinutes) notes.push("가상 이동시간이 포함되어 있습니다. 구간별 데이터 출처를 표시하며 실제 지도·도로 이동시간이 아닙니다.");
    if (stats.unknownOpeningCount) notes.push(`운영시간 확인 필요: ${stats.unknownOpeningCount}곳. 운영시간이 없는 장소의 실제 방문 가능 여부는 보장하지 않습니다.`);
    if (!options.date) notes.push("여행 날짜를 선택하지 않아 요일별 휴무를 확인하지 못했습니다. 등록된 시각과 체류시간만 비교합니다.");
    if (options.includePending) notes.push("관광 장소는 공식 원문 검증 전 조사 후보가 포함됩니다. 실제 여부·운영 상태·정확한 읍면을 확인해야 합니다.");
    if (stats.commercialMockCount || diningPlaces.length) notes.push("맛집·카페는 엑셀에서 가져온 가상 테스트 업소입니다. 메뉴·가격·운영·가상 읍면 배치 모두 창작이며 실제 방문·예약 정보가 아닙니다.");
    if (missing.length) notes.push("조건·영업시간·시간 예산·자료 부족으로 넣지 않은 관심사: " + missing.join(", ") + ". 조건에 맞지 않는 장소나 검색 안내를 방문 일정으로 채우지 않습니다.");
    if (selected.includes("축제")) notes.push(scheduledEvents.length ? "방문일과 겹치는 확인된 행사를 별도로 표시했습니다." : "확인된 개최 기간이 없어 축제를 일정에 임의로 넣지 않았습니다.");
    const lodgingSuggestions = [];
    if (count > 1 && !excluded.has("숙박")) lodgingSuggestions.push("숙소 찾기: 숙소·예약 자료가 미확인입니다. 야간 체류는 별도로 정하고 확정되지 않은 체크인을 시간표에 넣지 않았습니다.");
    if (excluded.has("숙박") && count > 1) notes.push("숙박 제외 요청을 반영했습니다. 여러 날 여행의 야간 체류는 별도 확인이 필요합니다.");
    if (selected.includes("숙박") && count === 1) notes.push("당일 일정에는 숙박을 넣지 않았습니다. 숙박이 필요하면 여행 기간을 늘려주세요.");
    return { days, notes, events: scheduledEvents, stats, missing, lodgingSuggestions, candidateCount: catalogue2.places.length, verifiedCount: catalogue2.places.filter((p) => p.verification === "verified").length, mockDiningCount: days.flatMap((d) => d.stops).filter((p) => p.isMock).length };
  }

  // ../../tmp/uidongi-usb-stage-76105qbw/public/app.js
  var defaults = () => ({ duration: "1박 2일", companion: "연인", interests: ["볼거리", "맛집"], excludedInterests: [], transport: "car", date: "", region: "all", environment: "any", pace: "normal", withPet: false, lodgingType: "any", includePending: true, includeMock: true, diningQuery: "", maxDiningPrice: "", parkingOnly: false, quiet: false, startTime: "09:30", availableHours: 16, travelAllowanceMinutes: "", themes: [] });
  var state = defaults();
  var currentTrip;
  var catalogue;
  var events = [];
  var dining = [];
  var travelTable = { routes: [], regionRoutes: [] };
  var dataWarnings = [];
  var $ = (selector) => document.querySelector(selector);
  var icons = { "반나절": "☀", "당일치기": "🌤", "1박 2일": "🌙", "2박 3일": "🧳", "혼자": "🚶", "연인": "♡", "친구": "🙌", "가족": "🏡", "볼거리": "🌿", "맛집": "🍚", "카페": "☕", "체험": "🎨", "특산물 쇼핑": "🛍", "축제": "🎉", "숙박": "🛏" };
  function element(tag, text, className) {
    const el = document.createElement(tag);
    if (text) el.textContent = text;
    if (className) el.className = className;
    return el;
  }
  function externalLink(text, href, className) {
    const a = element("a", text, className);
    a.href = href;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    return a;
  }
  function mapLink(query) {
    return externalLink("지도에서 확인 ↗", `https://map.naver.com/p/search/${encodeURIComponent(query)}`);
  }
  function badge(status, hold = false) {
    return element("span", hold ? "방문 후보에서 보류" : status === "fictional" ? "[가상] 테스트 전용" : status === "verified" ? "원문 확인" : status === "search" ? "업체 직접 찾기" : "원문·운영 확인 전", "status-badge" + (status === "verified" ? " verified" : ""));
  }
  function renderReasons(reasons) {
    const block = element("div", "", "recommendation-reasons");
    block.append(element("p", "추천 이유", "reasons-title"));
    const list = element("ul");
    list.setAttribute("aria-label", "추천 이유");
    for (const reason of reasons) {
      const item = element("li"), check = element("span", "✓", "reason-check");
      check.setAttribute("aria-hidden", "true");
      item.append(check, element("span", reason.text));
      list.append(item);
    }
    block.append(list);
    return block;
  }
  function renderChoices() {
    for (const [id, values, key] of [["duration-options", durations, "duration"], ["companion-options", companions, "companion"], ["interest-options", interests, "interests"]]) {
      const container = document.getElementById(id);
      container.replaceChildren();
      values.forEach((value) => {
        const button = element("button", `${icons[value]} ${value}`, "chip");
        button.type = "button";
        button.setAttribute("aria-pressed", key === "interests" ? state.interests.includes(value) : state[key] === value);
        button.addEventListener("click", () => {
          if (key === "interests") {
            if (state.interests.includes(value)) {
              state.interests = state.interests.filter((v) => v !== value);
              state.excludedInterests = [.../* @__PURE__ */ new Set([...state.excludedInterests, value])];
            } else {
              state.interests.push(value);
              state.excludedInterests = state.excludedInterests.filter((v) => v !== value);
            }
          } else {
            state[key] = value;
            if (key === "duration") {
              state.availableHours = defaultAvailableMinutes(value) / 60;
              $("#available-hours").value = state.availableHours;
            }
          }
          renderChoices();
          container.children[values.indexOf(value)].focus({ preventScroll: true });
        });
        container.append(button);
      });
    }
  }
  var controls = { transport: "#transport", date: "#travel-date", region: "#region", environment: "#environment", pace: "#pace", lodgingType: "#lodging-type", diningQuery: "#dining-query", maxDiningPrice: "#max-dining-price", startTime: "#start-time", availableHours: "#available-hours", travelAllowanceMinutes: "#travel-allowance" };
  function readControls() {
    for (const [key, selector] of Object.entries(controls)) state[key] = $(selector).value;
    state.includePending = $("#include-pending").checked;
    state.withPet = $("#with-pet").checked;
    state.includeMock = $("#include-mock").checked;
    state.parkingOnly = $("#parking-only").checked;
    state.quiet = $("#quiet-only").checked;
    state.themes = $("#nature-theme").checked ? ["nature"] : [];
  }
  function syncControls() {
    for (const [key, selector] of Object.entries(controls)) $(selector).value = state[key];
    $("#include-pending").checked = state.includePending;
    $("#with-pet").checked = state.withPet;
    $("#include-mock").checked = state.includeMock;
    $("#parking-only").checked = state.parkingOnly;
    $("#quiet-only").checked = state.quiet;
    $("#nature-theme").checked = state.themes?.includes("nature") || false;
  }
  function renderCatalogue() {
    if (!catalogue) return;
    const query = $("#catalogue-search").value.trim().toLowerCase();
    const category = $("#catalogue-category").value, region = $("#catalogue-region").value;
    const maxDiningPrice = Number($("#catalogue-budget").value);
    const compact = (text) => text.toLowerCase().replace(/\s+/g, "");
    const regular = maxDiningPrice ? [] : catalogue.places.filter((p) => compact([p.name, ...p.categories].join(" ")).includes(compact(query)) && (category === "all" || p.categories.includes(category)) && (region === "all" || p.region === region));
    const mocks = ["all", "맛집", "카페"].includes(category) ? searchDining(dining, { query, category, region, maxDiningPrice }) : [];
    $("#catalogue-count").textContent = `관광 조사 후보 ${catalogue.places.length}곳 · 가상 맛집 ${dining.filter((p) => p.category === "맛집").length}곳 · 가상 카페 ${dining.filter((p) => p.category === "카페").length}곳. 가상 업소는 실제 장소가 아닙니다.`;
    $("#catalogue-filter-status").textContent = `검색 결과 ${regular.length + mocks.length}곳 (관광 후보 ${regular.length}곳 / 가상 업소 ${mocks.length}곳)`;
    const cards = mocks.map((p) => {
      const card = element("article", "", "place-card mock-card");
      card.dataset.mock = "true";
      card.append(badge("fictional"), element("h3", p.name), element("p", `${p.category} · ${p.cuisine} · 가상 ${p.area} 배치`, "place-meta"), element("p", p.menu), element("p", `1인 예산 ${p.price.toLocaleString("ko-KR")}원 · ${p.minutes}분 체류 (모두 가정)`), element("p", `${p.atmosphere} · ${p.audiences.join("·")} · ${p.space}`, "place-meta"), element("p", p.openTime && p.closeTime ? `가상 영업 ${p.openTime}–${p.closeTime} / ${p.closedLabel || "확인 필요"}요일 휴무${p.breakTime ? " / 휴식 " + p.breakTime.join("–") : ""}` : "운영시간 확인 필요", "place-meta"), element("p", `주차 ${p.parking ? "있음" : "없음"} · 반려견 ${p.petPolicy} · 예약 ${p.reservation} (가정)`, "place-meta"), element("p", "실제 업소·주소·전화·예약 링크가 없는 창작 데이터입니다.", "mock-notice"));
      const button = element("button", "이 업소로 당일 코스 테스트 ↗", "text-button");
      button.type = "button";
      button.addEventListener("click", () => {
        readControls();
        state.interests = [p.category];
        state.excludedInterests = [];
        state.duration = "당일치기";
        state.availableHours = defaultAvailableMinutes(state.duration) / 60;
        state.region = p.region;
        state.diningQuery = p.name.replace("[가상] ", "");
        state.includeMock = true;
        syncControls();
        renderChoices();
        recommend();
      });
      card.append(button);
      return card;
    });
    cards.push(...regular.map((p) => {
      const card = element("article", "", "place-card");
      card.append(badge(p.verification, p.hold), element("h3", p.name), element("p", `${catalogue.meta.regions[p.region]} · ${p.categories.join(" / ")} · ${p.indoor ? "실내" : "야외"} 중심`, "place-meta"), element("p", p.description), element("p", `취향 제안: ${p.audiences.join("·")} / 체류 가정 ${p.minutes}분`, "place-meta"), element("p", `공식 확인일: ${p.sourceCheckedAt || "미확인"} · 운영시간·가격·정확한 주소: ${p.verification === "verified" ? "상세 출처 참고" : "미확인"}`, "place-meta"));
      if (p.hold) card.append(element("p", p.holdReason + " — 일정 자동 배치 제외", "hold-note"));
      card.append(mapLink("의성 " + p.name), externalLink(p.sourceUrl ? "확인한 원문 ↗" : "의성군에서 자료 확인 ↗", p.sourceUrl || "https://www.usc.go.kr/"));
      return card;
    }));
    $("#catalogue-list").replaceChildren(...cards);
    if (!cards.length) $("#catalogue-list").append(element("p", "일치하는 장소가 없습니다. 이름·메뉴·분류·권역·예산을 바꿔주세요.", "empty-state"));
  }
  function recommend() {
    readControls();
    if (!catalogue) {
      $("#data-status").textContent = "장소 자료를 불러오지 못했어요. 인터넷 연결 및 서버 실행을 확인하고 새로고침해 주세요.";
      return;
    }
    try {
      currentTrip = buildTrip(state, catalogue, events, dining, travelTable);
    } catch (error) {
      currentTrip = null;
      $("#results").hidden = true;
      $("#data-status").textContent = error.message;
      $("#data-status").scrollIntoView({ block: "center" });
      return;
    }
    currentTrip.notes.unshift(...dataWarnings);
    currentTrip.options = structuredClone(state);
    $("#results").hidden = false;
    $("#results-title").textContent = currentTrip.mockDiningCount ? "가상 업소가 포함된 테스트 코스" : state.includePending ? "취향에 맞춰 고른 확인 전 후보 코스" : "확인된 자료로 구성한 코스";
    const chosen = catalogue.meta.regions[state.region] || "취향에 맞는 권역";
    $("#result-summary").textContent = `${state.companion === "혼자" ? "혼자" : state.companion + " 동행"} · ${state.duration} · ${chosen}${state.date ? " · " + state.date + " 출발" : ""}. 매일 ${state.startTime} 시작 · 전체 활동 ${state.availableHours}시간 예산입니다.`;
    $("#result-tags").replaceChildren(...[state.duration, state.companion, ...state.interests, state.environment === "indoor" ? "실내 중심" : state.environment === "outdoor" ? "야외 중심" : "실내·야외", state.pace === "relaxed" ? "느긋하게" : state.pace === "active" ? "활동적으로" : "적당하게", state.transport === "car" ? "자가용" : "대중교통·택시", ...state.withPet ? ["반려견 동반"] : [], ...state.lodgingType === "camping" ? ["캠핑 후보"] : [], ...state.includeMock ? ["가상 업소 테스트"] : [], ...state.maxDiningPrice ? ["업소별 1인 " + Number(state.maxDiningPrice).toLocaleString("ko-KR") + "원 이하"] : [], ...state.diningQuery ? [state.diningQuery] : [], ...state.themes?.includes("nature") ? ["자연·힐링"] : []].map((v) => element("span", v)));
    const stats = currentTrip.stats;
    const metric = (label, value, detail) => {
      const card = element("div", "", "stat-card");
      card.append(element("span", label), element("strong", value), element("small", detail));
      return card;
    };
    $("#trip-stats").replaceChildren(
      metric("총 방문 장소", stats.totalVisitCount + "곳", "같은 장소 중복 없음"),
      metric("총 체류시간", stats.totalStayMinutes + "분", "기존 자료의 가정값"),
      metric("총 이동시간", stats.totalTravelMinutes === null ? "확인 필요" : stats.totalTravelMinutes + "분", stats.unknownTravelLegs ? `등록·입력값 ${stats.knownTravelMinutes}분 / 미확인 ${stats.unknownTravelLegs}구간` : `가상 ${stats.fictionalTravelMinutes}분 · 사용자 여유 ${stats.userAllowanceMinutes}분`),
      metric("지역 상권 연계 장소", stats.commercialCount + "곳", `가상 ${stats.commercialMockCount} · 조사 후보 ${stats.commercialCandidateCount} · 원문 확인 ${stats.commercialVerifiedCount}`)
    );
    $("#schedule-status").textContent = `활동 예산 ${stats.budgetMinutes}분 중 계산 가능한 합계 ${stats.plannedMinutes}분(대기 ${stats.totalWaitMinutes}분 포함). ` + (stats.timingProvisional ? "이동시간이 미확인인 임시 일정입니다. 이후 방문 시각은 최소 시각이며 실제 종료시간을 보장하지 않습니다." : "등록·입력한 시간 기준으로 예산 내 배치했습니다. 실제 운영·이동·예약은 확인이 필요합니다.") + ` 운영시간 미확인 ${stats.unknownOpeningCount}곳.`;
    $("#itinerary").replaceChildren(...currentTrip.days.map((day) => {
      const card = element("article", "", "day-card");
      card.append(element("h3", `DAY ${String(day.day).padStart(2, "0")} · ${day.region}`), element("p", `${day.date ? day.date + " · " : ""}${day.startTime}–${day.endTime} · 활동 예산 ${day.budgetMinutes}분 · 방문 ${day.stops.length}곳`, "day-meta"));
      if (!day.stops.length) card.append(element("p", "조건·운영시간·체류시간·활동 예산을 충족하는 방문지가 없습니다. 시간이나 조건을 조정해 주세요.", "empty-state"));
      day.timeline.forEach((item) => {
        const row = element("div", "", "stop timeline-item"), time = element("span", item.time + (item.endTime ? "–" + item.endTime : " → 미정"), "timeline-time"), content = element("div");
        row.dataset.kind = item.kind;
        if (item.kind === "travel") {
          row.classList.add("transfer-row");
          content.append(element("h4", "이동 · " + item.from + " → " + item.to), element("p", item.label + (item.minutes === null ? "" : " · " + item.minutes + "분")), element("p", "근거: " + (item.source || "구간·권역별 이동 자료 없음"), "source-note"));
        } else if (item.kind === "wait") {
          row.classList.add("wait-row");
          content.append(element("h4", item.label), element("p", item.minutes + "분 · 등록 운영시간에 맞춘 대기/휴식"));
        } else {
          content.append(badge(item.verification), element("h4", item.title), element("p", item.categories.join(" · ") + " / " + (item.isMock ? "가상 테스트 데이터" : item.verification === "verified" ? "실제 장소 · 원문 확인" : "관광 장소 조사 후보 · 실제 여부 미검증"), "place-meta"), element("p", item.description));
          if (item.reasons?.length) content.append(renderReasons(item.reasons));
          content.append(element("p", `체류 ${item.minutes}분(자료의 가정값) · 읍·면: ${item.area ? item.isMock ? "가상 배치 " + item.area : item.area : "확인 필요"} · ${day.region}`, "source-note"));
          content.append(element("p", item.openingLabel + (item.dateChecked ? "" : state.date ? " · 휴무정보 확인 필요" : " · 여행일 미지정으로 휴무 확인 필요"), "source-note"));
          if (item.incomingTravel) content.append(element("p", `직전 구간: ${item.incomingTravel.label}${item.incomingTravel.minutes === null ? "" : " " + item.incomingTravel.minutes + "분"} / 근거: ${item.incomingTravel.source || "등록 자료 없음"}`, "source-note"));
          if (item.bookingRequired) content.append(element("p", "운영·예약 가능 여부를 확인한 뒤 방문 확정", "source-note"));
          if (item.isMock) {
            row.dataset.mock = "true";
            content.append(element("p", "[가상] 실제 업소가 아니므로 지도·예약 기능을 제공하지 않습니다.", "mock-notice"));
          } else if (item.query) content.append(mapLink(item.query));
          if (item.sourceUrl) content.append(externalLink("확인한 원문 ↗", item.sourceUrl, "source-link"));
        }
        if (item.provisional) content.append(element("p", "이동 미확인 · 표시 시각은 확정 시각이 아닙니다.", "timing-note"));
        row.append(time, content);
        card.append(row);
      });
      if (day.missing.length) card.append(element("p", "이 날짜에 배치하지 않은 관심사: " + day.missing.join(", ") + " — 조건·운영시간·시간 예산 또는 다른 날짜의 코스를 확인해 주세요.", "missing-note"));
      return card;
    }));
    $("#dynamic-notes").replaceChildren(...[...currentTrip.notes, ...currentTrip.lodgingSuggestions].map((n) => element("p", n)));
    $("#event-results").replaceChildren(...currentTrip.events.map((event) => {
      const card = element("article", "", "event-card");
      card.append(element("h3", event.name), element("p", `${event.startDate} ~ ${event.endDate}`), externalLink("행사 공식 안내 ↗", event.sourceUrl));
      return card;
    }));
    $("#copy-status").textContent = "";
    $("#results").scrollIntoView({ behavior: "smooth", block: "start" });
  }
  $("#dining-query").addEventListener("input", () => {
    const query = $("#dining-query").value.trim();
    const exact = dining.find((p) => p.name.replace("[가상] ", "").replace(/\s+/g, "") === query.replace(/\s+/g, ""));
    const category = exact?.category || diningTextOptions(query).category;
    if (!category) return;
    const kinds = category === "all" ? ["맛집", "카페"] : [category];
    state.interests = [...state.interests.filter((c) => !["맛집", "카페"].includes(c)), ...kinds];
    state.excludedInterests = state.excludedInterests.filter((c) => !kinds.includes(c));
    renderChoices();
  });
  $("#trip-form").addEventListener("submit", (e) => {
    e.preventDefault();
    recommend();
  });
  $("#reset").addEventListener("click", () => {
    state = defaults();
    renderChoices();
    syncControls();
    $("#trip-prompt").value = "";
    $("#prompt-feedback").textContent = "";
    $("#results").hidden = true;
    currentTrip = null;
  });
  $("#example").addEventListener("click", () => {
    $("#trip-prompt").value = "연인이랑 1박2일로 맛집과 조용한 카페, 볼거리를 즐기고 의성 특산물도 사고 싶어. 자가용으로 느긋하게 여행할 거야!";
    $("#trip-prompt").focus();
  });
  $("#prompt-submit").addEventListener("click", () => {
    const text = $("#trip-prompt").value.trim();
    if (!text) {
      $("#prompt-feedback").textContent = "원하는 여행을 한 문장으로 알려주세요.";
      $("#trip-prompt").focus();
      return;
    }
    const parsed = parsePrompt(text);
    const named = dining.find((p) => text.replace(/\s+/g, "").includes(p.name.replace("[가상] ", "").replace(/\s+/g, "")));
    if (named) {
      parsed.diningQuery = named.name.replace("[가상] ", "");
      if (!parsed.interests.includes(named.category)) parsed.interests.push(named.category);
    } else if (parsed.interests.some((c) => ["맛집", "카페"].includes(c)) && !parsed.diningQuery) parsed.diningQuery = "";
    if (!Object.keys(parsed).some((k) => !["interests", "excludedInterests"].includes(k)) && !parsed.interests.length && !parsed.excludedInterests.length) {
      $("#prompt-feedback").textContent = "조건을 찾지 못했어요. “아이와 당일치기, 실내 체험”처럼 적어주세요.";
      return;
    }
    readControls();
    if (parsed.duration && parsed.availableHours === void 0) parsed.availableHours = defaultAvailableMinutes(parsed.duration) / 60;
    const prior = state.interests;
    state = { ...state, ...parsed, interests: (parsed.interests.length ? parsed.interests : prior).filter((c) => !parsed.excludedInterests.includes(c)) };
    renderChoices();
    syncControls();
    const recognized = [parsed.duration, parsed.companion, ...parsed.interests, ...parsed.excludedInterests.map((c) => c + " 제외"), parsed.environment === "indoor" ? "실내 중심" : parsed.environment === "outdoor" ? "야외 중심" : "", parsed.region ? catalogue?.meta.regions[parsed.region] : "", parsed.pace === "relaxed" ? "느긋하게" : parsed.pace === "active" ? "활동적으로" : "", parsed.transport === "public" ? "대중교통" : parsed.transport === "car" ? "자가용" : "", parsed.date, parsed.withPet ? "반려견 동반" : "", parsed.lodgingType === "camping" ? "캠핑 후보" : "", parsed.diningQuery, parsed.maxDiningPrice ? "업소별 1인 " + parsed.maxDiningPrice + "원 이하" : "", parsed.quiet ? "조용한 업소" : "", parsed.parkingOnly ? "주차 가능" : "", parsed.startTime ? parsed.startTime + " 시작" : "", parsed.availableHours ? parsed.availableHours + "시간 활동" : "", parsed.themes?.includes("nature") ? "자연·힐링" : ""].filter(Boolean);
    $("#prompt-feedback").textContent = "반영: " + recognized.join(" · ") + ". 언급하지 않은 조건은 현재 선택을 유지해요.";
    recommend();
  });
  $("#nature-theme").addEventListener("change", () => {
    if ($("#nature-theme").checked && !state.interests.includes("볼거리")) {
      state.interests.push("볼거리");
      state.excludedInterests = state.excludedInterests.filter((c) => c !== "볼거리");
      renderChoices();
    }
  });
  for (const button of document.querySelectorAll("[data-interest]")) button.addEventListener("click", () => {
    if (!state.interests.includes(button.dataset.interest)) state.interests.push(button.dataset.interest);
    state.excludedInterests = state.excludedInterests.filter((c) => c !== button.dataset.interest);
    renderChoices();
    $("#planner").scrollIntoView({ behavior: "smooth" });
  });
  for (const id of ["catalogue-search", "catalogue-category", "catalogue-region", "catalogue-budget"]) document.getElementById(id).addEventListener("input", renderCatalogue);
  $("#copy-trip").addEventListener("click", async () => {
    if (!currentTrip) return;
    const stats = currentTrip.stats;
    const text = [
      "의동이 픽 · " + currentTrip.options.duration,
      `방문 ${stats.totalVisitCount}곳 / 체류 ${stats.totalStayMinutes}분 / 이동 ${stats.totalTravelMinutes === null ? "확인 필요 (" + stats.unknownTravelLegs + "구간 미확인)" : stats.totalTravelMinutes + "분"} / 대기 ${stats.totalWaitMinutes}분`,
      `지역 상권 연계 장소 ${stats.commercialCount}곳 (가상 ${stats.commercialMockCount}, 조사 후보 ${stats.commercialCandidateCount}, 원문 확인 ${stats.commercialVerifiedCount})`,
      ...currentTrip.days.flatMap((day) => ["\nDAY " + day.day + " · " + day.region + (day.date ? " · " + day.date : ""), ...day.timeline.map((s) => {
        const time = s.time + (s.endTime ? "–" + s.endTime : " → 미정");
        if (s.kind === "travel") return `${time} 이동 ${s.from} → ${s.to} / ${s.label} / 근거 ${s.source || "자료 없음"}`;
        if (s.kind === "wait") return `${time} ${s.label} ${s.minutes}분`;
        return `${time} ${s.title} / ${s.categories.join("·")} / 체류 ${s.minutes}분
읍·면 ${s.area || "확인 필요"} / ${s.openingLabel} / ${s.provisional ? "이동 미확인 최소 시각" : "등록·입력값 기준"}
${s.reason}
${s.isMock ? "[가상] 실제 방문·예약 불가" : s.sourceUrl || "관광 장소 조사 후보"}`;
      })]),
      "\n확인 사항",
      ...currentTrip.notes,
      ...currentTrip.lodgingSuggestions
    ].join("\n");
    try {
      await navigator.clipboard.writeText(text);
      $("#copy-status").textContent = "확인 사항과 함께 일정을 복사했어요.";
    } catch {
      $("#copy-status").textContent = "아래 내용을 직접 복사해 주세요.";
      const area = element("textarea");
      area.value = text;
      area.readOnly = true;
      area.setAttribute("aria-label", "복사할 여행 일정");
      $("#copy-status").append(area);
      area.select();
    }
  });
  async function init() {
    renderChoices();
    syncControls();
    const buttons = [$('#trip-form button[type="submit"]'), $("#prompt-submit")];
    buttons.forEach((b) => b.disabled = true);
    try {
      const data = await loadTripData();
      ({ catalogue, dining, events, travelTable } = data);
      dataWarnings = data.warnings;
      $("#data-status").textContent = `관광 후보 ${catalogue.places.length}곳 · 가상 맛집·카페 ${dining.length}곳. 관광지 운영시간·읍면과 이동시간은 미확인 자료가 있습니다. ` + dataWarnings.join(" ");
      renderCatalogue();
      buttons.forEach((b) => b.disabled = false);
    } catch (error) {
      $("#data-status").textContent = error.message;
      $("#catalogue-count").textContent = "장소 자료 로딩 실패";
    }
  }
  init();
})();
