@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title 의동이 PICK USB 실행
set "UIDONGI_NODE=%~dp0node\node.exe"
if /I "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "UIDONGI_NODE=%~dp0node\node-arm64.exe"
if /I "%PROCESSOR_ARCHITEW6432%"=="ARM64" set "UIDONGI_NODE=%~dp0node\node-arm64.exe"
if not exist "%UIDONGI_NODE%" (
  echo [오류] 포함된 Node.js 파일을 찾을 수 없습니다.
  echo USB 폴더 전체를 복사했는지 확인하거나 index.html을 직접 여세요.
  pause
  exit /b 1
)
echo 의동이 PICK을 준비합니다. 이 창을 닫으면 서버가 종료됩니다.
"%UIDONGI_NODE%" "%~dp0server\launcher.cjs"
if errorlevel 1 (
  echo.
  echo [오류] 서버 실행에 실패했습니다. 위 오류를 확인하세요.
  echo index.html을 직접 열면 보조 실행할 수 있습니다.
)
pause
endlocal
